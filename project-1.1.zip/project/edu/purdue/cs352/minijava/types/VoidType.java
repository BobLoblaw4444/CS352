package edu.purdue.cs352.minijava.types;

public class VoidType extends StaticType {
    @Override public String toString() { return "void"; }
}
